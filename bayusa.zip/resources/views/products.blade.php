@extends('layouts.app-orange')

@section('content')
  @include('store.partials.products_home')
@endsection
