@extends('layouts.app-orange')

@section('content')
    @include('store.partials._promociones')
@stop