@extends('layouts.app-orange')

@section('content')
    @include('store.partials._submenup')
    @include('store.partials.products')
@stop
