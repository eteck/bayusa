<div class="container-fluid">
	<div class="page-header">
  		<h1>¡Proximamente,<small> esperalas </small>!</h1>
	</div>
 </div>