@extends('layouts.app-orange')

@section('content')
    
    <div class="container-fluid">
    	@include('store.partials.slider')
    	@include('store.partials.products')
    </div>
@stop
