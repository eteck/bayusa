<?php $__env->startSection('main-content'); ?>
	<div class="box box-info">
        <div class="box-header with-border">
            <h3 class="box-title">
        		<i class="fa fa-cog"></i> Categorias [Editar Categoria]
        	</h3>
        </div>
		<?php if(count($errors) > 0): ?>
			<?php echo $__env->make('admin.partials.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php endif; ?>
        <div class="box-body">

            <?php echo Form::model($category,['route'=>['admin.category.update',$category],'method'=>'PUT']); ?>

            	<div class="form-group">
            		
            		<?php echo Form::Label('Nombre: '); ?>

            		<?php echo Form::text(
            			'name',
            			null,
            			array(
            				'class'=>'form-control',
            				'required'=>'required',
							'placeholder'=>'Nombre categoria',
							'autofocus'=>'autofocus'
            			)
            		); ?>

            	</div>

            	<div class="form-group">
            		<?php echo Form::Label('Description: '); ?>

            		<?php echo Form::textarea(
            			'description',
            			null,
            			array(
            				'class'=>'form-control',
            				'required'=>'required',
							'placeholder'=>'Descripción categoria'
            			)
            		); ?>

            	</div>

            	<div class="form-group">
            		<?php echo Form::Label('Categoria: '); ?>

            		<?php echo Form::select(
            			'parent_id',
						$categorias_padre,
						null,
						['class'=>'form-control']
            		); ?>

            	</div>

            	<div class="form-group">
            		<?php echo Form::submit('Actualizar',array('class'=>'btn btn-primary')); ?>

            		<a href="<?php echo e(route('admin.category.index')); ?>" class="btn btn-warning">Cancelar</a>
            	</div>
			<?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>