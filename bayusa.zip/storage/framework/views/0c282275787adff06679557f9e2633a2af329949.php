<?php $__env->startSection('content'); ?>
<div class="container-fluid text-center">
  <div class="page-header">
    <h3><i class="fa fa-shopping-cart"></i> Detalle del Producto</h3>
  </div>

  <articule class="row">
    <div class="col-md-6">
      <div class="product-block">
        <img src="../recursos/img/products/<?php echo e($product->image); ?>" width="300">
      </div>
    </div>
    <div class="col-md-6">
      <div class="product-block">
        <h4><?php echo e($product->name); ?></h4><hr>
        <div class="product-info panel panel-body">
          <p> <?php echo e($product->description); ?> </p>
          <?php if(!Auth::guest()): ?>
            <span class="btn btn-success">Precio: $ <?php echo e(number_format($product->price,2)); ?></span>
          <?php endif; ?>
          <span>
            <a class="btn btn-primary" href="<?php echo e(route('cart-add',$product->slug)); ?>"><i class="fa fa-cart-plus"></i> Lo quiero</a>            
          </span>
          <span>
            <a class="btn btn-info" href="<?php echo e(route('welcome')); ?>"><i class="fa fa-chevron-circle-left"></i> Regresar</a>
          </span>
        </div>
      </div>
    </div>
  </articule>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-orange', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>