<section class="container">
	<h4><?php echo e($category->name); ?></h4> <span class="btn btn-bayusa"><span class="badge"><?php echo e($category->replies->count()); ?></span> - Subcategorias </span>
	<?php foreach($categories as $menu): ?>
		<?php if($menu->replies->count()): ?>
			<div class="row alert alert-success">
				<i class="fa fa-level-down" aria-hidden="true"></i> <?php echo e($menu->name); ?> (<span class="badge"><?php echo e($menu->products->count()); ?></span> - Productos)
			</div>
			<div class="row">
				<?php foreach($menu->products as $product): ?>
						<div  class="col-xs-12 col-sm-6 col-md-4">
							<div class="thumbnail center-block" style="height: 150;">
								<div class="center-block" style="width: 150; height: 150;">
									<img src="<?php echo e(asset('recursos/img/products/'.$product->image)); ?>" style="max-width: 150px; max-height: 150px;" class="img-thumbnail img-responsive" alt="<?php echo e($product->name); ?>">
									<div class="center-block">
									<?php if(!Auth::guest()): ?>
										<span class="btn btn-success">Precio: $ <?php echo e(number_format($product->price,2)); ?></span>
									<?php endif; ?>
									</div>
								</div>
								<hr>
								<div class="caption text-center" style="height: 100px">
									<spam><?php echo e($product->stract); ?></spam>
									<hr>
									<div class="text-center">
										<a class="btn btn-bayusa" href="<?php echo e(route('cart-add',$product->slug)); ?>"><i class="fa fa-cart-plus"></i> <spam class="hidden-xs hidden-sm">Lo quiero</spam></a>
										<a class="btn btn-warning" href="<?php echo e(route('product-datail', $product->slug)); ?>"><i class="fa fa-chevron-circle-right"></i> <spam class="hidden-xs hidden-sm"> Leer más </spam> </a>
									</div>
								</div>
							</div>
						</div>
				<?php endforeach; ?>
			</div>
			<div class="container">
				<?php foreach($menu->replies as $submenu): ?>
					<div class="row alert alert-success">
						<i class="fa fa-hashtag" aria-hidden="true"></i> <?php echo e($submenu->name); ?> (<span class="badge"><?php echo e($submenu->products->count()); ?></span> - Productos)
					</div>
					<div class="row">
						<?php foreach($submenu->products as $product): ?>
						<div  class="col-xs-12 col-sm-6 col-md-4">
							<div class="thumbnail center-block" style="height: auto;">
								<div class="center-block" style="width: 150px; height: auto;">
									<img src="<?php echo e(asset('recursos/img/products/'.$product->image)); ?>" style="max-width: 150px; max-height: 150;" class="img-thumbnail img-responsive" alt="<?php echo e($product->name); ?>">
									<div class="center-block">
									<?php if(!Auth::guest()): ?>
										<span class="btn btn-success">Precio: $ <?php echo e(number_format($product->price,2)); ?></span>
									<?php endif; ?>
									</div>
								</div>
								<hr>
								<div class="caption text-center" style="height: 100px">
									<spam><?php echo e($product->stract); ?></spam>
									<hr>
									<div class="text-center">
										<a class="btn btn-bayusa" href="<?php echo e(route('cart-add',$product->slug)); ?>"><i class="fa fa-cart-plus"></i> <spam class="hidden-xs hidden-sm">Lo quiero</spam></a>
										<a class="btn btn-warning" href="<?php echo e(route('product-datail', $product->slug)); ?>"><i class="fa fa-chevron-circle-right"></i> <spam class="hidden-xs hidden-sm"> Leer más </spam> </a>
									</div>
								</div>
							</div>
						</div>
						<?php endforeach; ?>
					</div>
				<?php endforeach; ?>
			</div>
		<?php else: ?>
		<div class="row alert alert-success">
			<i class="fa fa-minus-square-o" aria-hidden="true"></i> <?php echo e($menu->name); ?> (<span class="badge"><?php echo e($menu->products->count()); ?></span> - Productos)
		</div>
		<div class="row">
			<?php foreach($menu->products as $product): ?>
				<div  class="col-xs-12 col-sm-6 col-md-4">
					<!--span><?php echo e($product->name); ?></span><hr-->
					<div class="thumbnail center-block" style="height: auto;">
						<div class="center-block" style="width: 150px; height: auto;">
							<img src="<?php echo e(asset('recursos/img/products/'.$product->image)); ?>" style="max-width: 150px; max-height: auto" class="img-thumbnail img-responsive" alt="<?php echo e($product->name); ?>">
							<div class="center-block">
							<?php if(!Auth::guest()): ?>
								<span class="btn btn-success">Precio: $ <?php echo e(number_format($product->price,2)); ?></span>
							<?php endif; ?>
							</div>
						</div>
						<hr>
						<div class="caption text-center" style="height: 100px">
							<spam><?php echo e($product->stract); ?></spam>
							<hr>
							<div class="text-center">
								<a class="btn btn-bayusa" href="<?php echo e(route('cart-add',$product->slug)); ?>"><i class="fa fa-cart-plus"></i> <spam class="hidden-xs hidden-sm">Lo quiero</spam></a>
								<a class="btn btn-warning" href="<?php echo e(route('product-datail', $product->slug)); ?>"><i class="fa fa-chevron-circle-right"></i> <spam class="hidden-xs hidden-sm"> Leer más </spam> </a>
							</div>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>	
	<?php endforeach; ?>
</section>