<?php $__env->startSection('content'); ?>
	<div class="container text-center">
		<?php if(!Auth::guest()): ?>
		<div class="page-header">
			<h3><i class="fa fa-shopping-cart">Resumen del Pedido</i></h3>
		</div>

		<div class="page">
			
			<div class="table-responsibe">
				<h3>Datos del usuario</h3>
				<table class="table table-stripe table-hover table-bordered">
					<tr>
						<td>Nombre: </td>
						<td><?php echo e(Auth::user()->name. " " . Auth::user()->last_name); ?></td>
					</tr>
					<tr>
						<td>Usuario: </td>
						<td><?php echo e(Auth::user()->username); ?></td>
					</tr>
					<tr>
						<td>Correo: </td>
						<td><?php echo e(Auth::user()->email); ?></td>
					</tr>
					<tr>
						<td>Dirección: </td>
						<td><?php echo e(Auth::user()->address); ?></td>
					</tr>
					
				</table>
			</div>
			
			<div class="table-responsibe">
				<h3>Datos del Pedido</h3>
				<table class="table tables-triped table-hover table-bordered">
					<thead>
						<tr>
							<th>Producto</th>
							<th>Precio</th>
							<th>Cantidad</th>
							<th>Subtotal</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($cart as $item): ?>
							<tr>
								<td><?php echo e($item->name); ?></td>
								<td><?php echo e(number_format($item->price,2)); ?></td>
								<td><?php echo e($item->quantity); ?></td>
								<td><?php echo e(number_format($item->price * $item->quantity,2)); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table><hr>
				<h3>
					<span class="label label-success">
						Total: $ <?php echo e(number_format($total,2)); ?>

					</span>
				</h3><hr>
				<p>
					<a href="<?php echo e(route('cart-show')); ?>" class="btn btn-primary">
						<i class="fa fa-chevron-circle-left"> Regresar</i>
					</a>
					<a href="<?php echo e(route('order-request')); ?>" class="btn btn-info">
						<i class="fa fa-chevron-circle-right"> Solicitar Pedido</i>
					</a>
					<a href="<?php echo e(route('payment')); ?>" class="btn btn-warning">
						<i class="fa fa-cc-paypal"> Paypal</i>
					</a>
				</p>

			</div>
			
		</div>
		<?php else: ?>
			<h3><span class="label label-warning">Es necesario registrarse para confirmar su pedido</span></h3>
		<?php endif; ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-orange', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>