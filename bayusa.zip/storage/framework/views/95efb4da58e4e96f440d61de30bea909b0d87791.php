<?php $__env->startSection('main-content'); ?>
	<div class="box">
        <div class="box-header">
        	<h3 class="box-title">
        		<i class="fa fa-cog"></i> Categorias [Lista de Categorias]
        	</h3>
        </div><!-- /.box-header -->
        <span><a href="<?php echo e(route('admin.category.create')); ?>" class="btn btn-warning"><i class="fa fa-plus-circle"></i> Categoria</a></span>
        <div class="box-body">
        	<div class="table-responsive">
		        <table id="categoryTable" class="table table-bordered table-striped">
		        	<thead>
		            	<tr>
		                    <th>ID</th>
		                    <th>Nombre</th>
		                    <th>Slug</th>
		                    <th>Descripcion</th>
		                    <th>Eliminar</th>
		                    <th>Editar</th>
		                </tr>
		            </thead>
		            <tbody>
						<?php foreach($categorias as $categoria): ?>
							<tr>
								<td>
									<?php echo e($categoria->id); ?>

								</td>
								<td>
									<?php echo e($categoria->name); ?>

								</td>
								<td>
									<?php echo e($categoria->slug); ?>

								</td>
								<td>
									<?php echo e($categoria->description); ?>

								</td>
								<td>
									<?php echo Form::open(['route'=>['admin.category.destroy',$categoria],'method'=>'DELETE']); ?>

									<button onclick="return confirm('¿Eliminar Registro?')" class="btn btn-danger"><i class="fa fa-trash"></i></button>
									<?php echo Form::close(); ?>

								</td>
								<td>
									<a href="<?php echo e(route('admin.category.edit',$categoria)); ?>" class="btn btn-primary"><i class="fa fa-pencil-square"></i></a>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>