<?php $__env->startSection('main-content'); ?>
	<div class="box">
        <div class="box-header">
        	<h3 class="box-title">
        		<i class="fa fa-cog"></i> Ordenes PayPal [Lista de Ordenes]
        	</h3>
        </div><!-- /.box-header -->
        <div class="box-body">
        	<div class="table-responsive">
		        <table id="categoryTable" class="table table-bordered table-striped">
		        	<thead>
		            	<tr>
		                    <th>ID</th>
		                    <th>Cliente</th>
		                    <th>Subtotal</th>
		                    <th>Gastos de envio</th>
		                    <th>Total</th>
		                    <th>Fecha</th>
		                    <th>Opciones</th>
		                </tr>
		            </thead>
		            <tbody>
						<?php foreach($orders as $order): ?>
							<tr>
								<td>
									<?php echo e($order->id); ?>

								</td>
								<td>
									<?php echo e($order->user->name." ".$order->user->last_name); ?>

								</td>
								<td>
									$ <?php echo e(number_format($order->subtotal,2)); ?>

								</td>
								<td>
									$ <?php echo e(number_format($order->shipping,2)); ?>

								</td>
								<td>
									$ <?php echo e(number_format(($order->subtotal + $order->shipping),2)); ?>

								</td>
								<td>
									<?php echo e(date('d/M/Y', strtotime($order->created_at))); ?>

								</td>
								<td>
									<a href="<?php echo e(route('admin.order.detail',$order->id)); ?>" class="btn btn-primary"><i class="fa fa-eye" aria-hidden="true"></i></a>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>