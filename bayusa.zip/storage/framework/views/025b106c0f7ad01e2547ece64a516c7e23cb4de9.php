<?php $__env->startSection('main-content'); ?>
	<div class="box">
        <div class="box-header">
        	<h3 class="box-title">
        		<i class="fa fa-cog"></i> Productos [Lista de Productos] 
        	</h3>
        </div><!-- /.box-header -->
        <span><a href="<?php echo e(route('admin.product.create')); ?>" class="btn btn-warning"><i class="fa fa-plus-circle"></i> Producto</a></span>
        <div class="box-body">
        	<div class="table-responsive">
		        <table id="productTable" class="table table-bordered table-striped">
		        	<thead>
		            	<tr>
		                    <!--th>ID</th-->
		                    <th>Imagen</th>
		                    <th>Nombre</th>
		                    <!--th>Categoria</th>
		                    <th>Slug</th>
		                    <th>Descripcion</th-->
		                    <th>Descripción corta</th>
		                    <th>Cantidad</th>
		                    <!--th>Precio</th>
		                    <th>Activo</th-->
		                    <th>Eliminar</th>
		                    <th>Editar</th>
		                </tr>
		            </thead>
		            <tbody>
						<?php foreach($products as $product): ?>
							<tr>
								<!--td>
									<?php echo e($product->id); ?>

								</td-->
								<td>
									<img src="../recursos/img/products/<?php echo e($product->image); ?>" width="40" alt="">
								</td>
								<td>
									<?php echo e($product->name); ?>

								</td>
								<!--td>
									<?php echo e($product->category->name); ?>

								</td>
								<td>
									<?php echo e($product->slug); ?>

								</td>
								<td>
									<?php echo e($product->description); ?>

								</td-->
								<td>
									<?php echo e($product->stract); ?>

								</td>
								<td>
									<?php echo e(number_format($product->quantity)); ?>

								</td>
								<!--td>
									$<?php echo e(number_format($product->price,2)); ?>

								</td>
								<td>
									<?php echo e($product->visible == 1 ? 'Si':'No'); ?>

								</td-->
								<td>
									<?php echo Form::open(['route'=>['admin.product.destroy',$product->slug],'method'=>'DELETE']); ?>

									<button onclick="return confirm('¿Eliminar Registro?')" class="btn btn-danger"><i class="fa fa-trash"></i></button>
									<?php echo Form::close(); ?>

								</td>
								<td>
									<a href="<?php echo e(route('admin.product.edit',$product->slug)); ?>" class="btn btn-primary"><i class="fa fa-pencil-square"></i></a>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>