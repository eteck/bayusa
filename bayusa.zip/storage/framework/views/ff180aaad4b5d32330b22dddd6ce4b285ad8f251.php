<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('store.partials._politicas', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-orange', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>