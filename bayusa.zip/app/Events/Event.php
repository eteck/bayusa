<?php

namespace bayusa\Events;

abstract class Event
{
    //
}
