<!-- jQuery 2.1.4 -->
<script src="{{asset('recursos/plugins/jquery/js/jquery-2.2.0.min.js')}}"></script>
<!--script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script-->
<script src="{{asset('recursos/plugins/bootstrap/js/bootstrap.min.js')}}"></script>
<!-- iCheck -->
<script src="{{ asset('recursos/plugins/iCheck/icheck.min.js') }}" type="text/javascript"></script>