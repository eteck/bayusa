<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        <a href="https://github.com/acacha/adminlte-laravel"></a><b>Panel de Control - Bayusa</b></a>. 
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2016 <a href="http://acacha.org">Bayusa de México S.A de C.V</a>.</strong> Creado por <a href="http://salmondesing.com.mx">Salmon Desing</a>
</footer>