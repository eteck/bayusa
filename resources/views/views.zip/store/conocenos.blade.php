@extends('layouts.app-orange')

@section('content')
    @include('store.partials._conocenos')
@stop